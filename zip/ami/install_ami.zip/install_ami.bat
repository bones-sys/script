@echo off
chcp 65001 >nul

for /f "tokens=3 delims=\ " %%i in ('whoami /groups^|find "Mandatory"') do set LEVEL=%%i
if NOT "%LEVEL%"=="High" (
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -Command "Start-Process '%~f0' -Verb runas"
exit
)

set VER=3.0.0
title Install action-menu-item Ver %VER%

echo --------------------------------------------
echo slackの設定を変更しています...
set "jsonFilePath="

for %%P in (
    "%APPDATA%\Slack\storage\root-state.json"
    "%LOCALAPPDATA%\Packages\91750D7E.Slack_8she8kybcnzg4\LocalCache\Roaming\Slack\storage\root-state.json"
    "%LOCALAPPDATA%\Packages\com.tinyspeck.slackdesktop_8yrtsj140pw4g\LocalCache\Roaming\Slack\storage\root-state.json"
) do (
    if exist "%%~P" (
        set "jsonFilePath=%%~P"
        goto :SlackJsonFound
    )
)

:SlackJsonFound

if exist "%jsonFilePath%" (
    setlocal enabledelayedexpansion
    set "PSCOMMAND="
    set "PSCOMMAND=!PSCOMMAND! $jsonContent = Get-Content -Path '%jsonFilePath%' | ConvertFrom-Json;"
    set "PSCOMMAND=!PSCOMMAND! $jsonContent.settings.userChoices | Add-Member -MemberType NoteProperty -Name 'win32' -Value @{ 'windowFlashBehavior' = 'always'; 'hasExplainedWindowFlash' = $true } -Force;"
    set "PSCOMMAND=!PSCOMMAND! $jsonContent.settings.userChoices | Add-Member -MemberType NoteProperty -Name 'notificationMethod' -Value 'winrt' -Force;"
    set "PSCOMMAND=!PSCOMMAND! $jsonContent.settings.userChoices | Add-Member -MemberType NoteProperty -Name 'runFromTray' -Value $true -Force;"
    set "PSCOMMAND=!PSCOMMAND! $jsonContent.settings.userChoices | Add-Member -MemberType NoteProperty -Name 'hideOnStartup' -Value $true -Force;"
    set "PSCOMMAND=!PSCOMMAND! $jsonContent.settings.userChoices | Add-Member -MemberType NoteProperty -Name 'locale' -Value 'ja-JP' -Force;"
    set "PSCOMMAND=!PSCOMMAND! $jsonUpdated = $jsonContent | ConvertTo-Json -Depth 10;"
    set "PSCOMMAND=!PSCOMMAND! Set-Content -Path '%jsonFilePath%' -Value $jsonUpdated;"
    powershell -NoProfile -ExecutionPolicy RemoteSigned -Command "!PSCOMMAND!"
    endlocal
) else (
    echo ファイルが見つかりません: %jsonFilePath%
)
echo --------------------------------------------
echo.
echo.

echo --------------------------------------------
echo ami_versionフォルダを初期化しています...
if exist "%USERPROFILE%\ami_version" (
    curl http://localhost:51000/api/signal
    timeout /t 1
    rmdir /s /q "%USERPROFILE%\ami_version"
)
echo --------------------------------------------
echo.
echo.
if exist "%USERPROFILE%\ami_version" (
    echo --------------------------------------------
    echo フォルダの削除に失敗しました。手動で削除して再度実行してください: %USERPROFILE%\ami_version
    echo --------------------------------------------
    echo.
    echo.
    pause
    goto End
)
mkdir "%USERPROFILE%\ami_version"

set REMOTE_FOLDER=\\bs00\Bon_system\ami_launcher
set LAUNCHER_FOLDER=%USERPROFILE%\ami_launcher

set CHROME_HKEY=HKLM\SOFTWARE\Policies\Google\Chrome\URLWhitelist
set LAUNCHER_HKEY=HKCR\ami
set LAUNCH_LAUNCHER="\"%LAUNCHER_FOLDER%\ami_launcher.exe\" \"%%1\""
set OPLINK_HKEY=HKCR\oplink
set LAUNCH_OPLINK="\"%LAUNCHER_FOLDER%\oplink.exe\" \"%%1\""

echo action-menu-item インストール Ver.%VER%
echo.
echo.

echo --------------------------------------------
echo パスを脅威の保護の対象から除外中です...

powershell Add-MpPreference -ExclusionPath %USERPROFILE%\ami_version
powershell Add-MpPreference -ExclusionPath '%LAUNCHER_FOLDER%'
powershell Add-MpPreference -ExclusionPath \\bs00\Bon_system

echo --------------------------------------------
echo.
echo.


cd /d %~dp0

echo.
echo --------------------------------------------
echo インストール中です...

timeout /t 1 /nobreak >nul
echo.

if exist %REMOTE_FOLDER% (
    if exist %LAUNCHER_FOLDER% (
        rmdir /s /q %LAUNCHER_FOLDER%
        echo 既存のフォルダを削除しました
    )

    robocopy %REMOTE_FOLDER% %LAUNCHER_FOLDER% /s /MT:16
    reg add %CHROME_HKEY% /v "1" /t "REG_SZ" /d "ami://*" /f

    reg add %LAUNCHER_HKEY% /t "REG_SZ" /d "URL:ami" /f
    reg add %LAUNCHER_HKEY% /v "URL Protocol" /t "REG_SZ" /d "" /f
    reg add %LAUNCHER_HKEY%\shell\open\command /t "REG_SZ" /d %LAUNCH_LAUNCHER% /f

    reg add %OPLINK_HKEY% /t "REG_SZ" /d "URL:oplink" /f
    reg add %OPLINK_HKEY% /v "URL Protocol" /t "REG_SZ" /d "" /f
    reg add %OPLINK_HKEY%\shell\open\command /t "REG_SZ" /d %LAUNCH_OPLINK% /f

    if not "%ERRORLEVEL%" == "0" (
            echo インストール中にエラーが発生しました
            pause
            goto End
    ) else (
        echo インストールは完了しました
        echo.
    )
) else (
    echo %REMOTE_FOLDER% が存在しません、社内ネットワークに接続して再度実行してください。
    pause
    goto End
)
echo --------------------------------------------
:End

echo.
echo --------------------------------------------
echo ショートカットを作成しています...
for /f "usebackq delims=" %%D in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Desktop')"`) do set "DESKTOP=%%D"
for /f "usebackq delims=" %%S in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Programs')"`) do set "STARTMENU=%%S"

set "EXE=%USERPROFILE%\ami_launcher\ami_launcher.exe"

powershell -Command "$wsh = New-Object -ComObject WScript.Shell; $s = $wsh.CreateShortcut('%DESKTOP%\ami_launcher.lnk'); $s.TargetPath = '%EXE%'; $s.Save()"

powershell -Command "$wsh = New-Object -ComObject WScript.Shell; $s = $wsh.CreateShortcut('%STARTMENU%\ami_launcher.lnk'); $s.TargetPath = '%EXE%'; $s.Save()"
echo --------------------------------------------


echo.
echo.
echo バッチを終了します

timeout /t 1 /nobreak >nul